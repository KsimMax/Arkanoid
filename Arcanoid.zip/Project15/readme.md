Создание игры Arcanoid на языке C++ с использованием библиотеки SFML
 
КАЧАН МАКСИМ 18.09.2024

На всякий случай закинул код сюда 

↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓



#include <SFML/Graphics.hpp>
#include <time.h>
#include <vector>
#include <iostream>

using namespace sf;
using namespace std;

// класс с объектами игры
class Objects {
public:
    RectangleShape player;
    CircleShape ball;
    vector<RectangleShape> blocks;
    CircleShape reset;
    CircleShape back;
    ConvexShape start; 
    RectangleShape exit;
    Text title;
    Text scoreText; 
};

// класс переменных типа bool (состояние игры)
class Boolean {
public:
    bool menu = true, game = false, gameOver = false;
};

// функция для сброса игры
void resetGame(Objects& o, int rows, int cols, float blockSpacing) {
    o.blocks.clear();
    for (int i = 0; i < cols; ++i) {
        for (int j = 0; j < rows; ++j) {
            RectangleShape block(Vector2f(100, 50));
            block.setPosition(10 + i * (100 + blockSpacing), 50 + j * (80 + blockSpacing)); // установка позиции блоков
            block.setFillColor(Color(115, 209, 176));
            o.blocks.push_back(block);
        }
    }
    o.ball.setPosition(600, 350);
    o.ball.setRadius(25); 
    o.ball.setFillColor(Color(209, 115, 193)); 
    o.player.setPosition(400, 600); 
    o.player.setSize(Vector2f(200, 30)); 
    float kx = 0.3f;
    float ky = 0.3f;
    kx = 0.3f;
    ky = 0.3f;
}

// функция для обновления игры
void update(Objects& o, Boolean& b, float& kx, float& ky, int& score) {
    if (b.game && !b.gameOver) {
        o.ball.move(0.75 * kx, 0.75 * ky);       // перемещение мяча
        Vector2f b1 = o.ball.getPosition();
        if (b1.y < 0) {
            ky *= -1; // изменение направления мяча при столкновении с верхней стенкой
        }
        if (b1.x > 1110 || b1.x < 0) {
            kx *= -1; // изменение направления мяча при столкновении с боковыми стенками
        }
        if (o.ball.getGlobalBounds().intersects(o.player.getGlobalBounds())) {
            ky *= -1; // изменение направления мяча при столкновении с игроком
            o.ball.move(0, -0.5);
        }

        // проверка столкновения с блоками
        for (auto it = o.blocks.begin(); it != o.blocks.end();) {
            if (o.ball.getGlobalBounds().intersects(it->getGlobalBounds())) {
                ky *= -1; // изменение направления мяча при столкновении с блоком
                it = o.blocks.erase(it); // удаление блока
                score++;
            }
            else {
                ++it;
            }
        }

        if (Keyboard::isKeyPressed(Keyboard::A)) {
            o.player.move(-0.75, 0);
        }
        if (Keyboard::isKeyPressed(Keyboard::D)) {
            o.player.move(0.75, 0);
        }

        // проверка, если мяч упал ниже окна
        if (b1.y > 800) {
            b.gameOver = true; 
        }
    }
}

int main() {
    RenderWindow window(VideoMode(1200, 800), "Arkanoid");
    window.clear(Color(255, 127, 80));
    Objects o;
    Boolean b;

    // инициализация форм
    o.player.setSize(Vector2f(200, 30));
    o.player.setFillColor(Color(181, 7, 152)); 
    o.ball.setRadius(25);
    o.ball.setFillColor(Color(209, 115, 193));
    o.reset.setRadius(50);
    o.reset.setFillColor(Color(163, 153, 10));
    o.reset.setPosition(1000, 650);
    o.back.setRadius(50);
    o.back.setFillColor(Color(28, 10, 163));
    o.back.setPosition(100, 650);

    // инициализация кнопки START - СТАРТ
    o.start.setPointCount(3);
    o.start.setPoint(0, Vector2f(0, 0));
    o.start.setPoint(1, Vector2f(100, 50));
    o.start.setPoint(2, Vector2f(0, 100));
    o.start.setFillColor(Color(23, 117, 33));
    o.start.setPosition(600, 400);

    // инициализация кнопки EXIT - ВЫХОД
    o.exit.setSize(Vector2f(100, 100));
    o.exit.setFillColor(Color(163, 10, 12));
    o.exit.setPosition(475, 400);

    // текст в меню
    Font font;
    if (!font.loadFromFile("arial_narrow_7.ttf")) {
        cout << "Error loading font" << endl;
        return -1;
    }
    o.title.setFont(font);
    o.title.setString("Arkanoid");
    o.title.setCharacterSize(100);
    o.title.setFillColor(Color(181, 7, 152));
    o.title.setPosition(425, 200);

    // инициализация текста для вывода счета
    o.scoreText.setFont(font);
    o.scoreText.setCharacterSize(30);
    o.scoreText.setFillColor(Color::Black);
    o.scoreText.setPosition(550, 700);

    // инициализируем блоки
    resetGame(o, 3, 9, 30.0f);

    float kx = 0.3f; // скорость мяча
    float ky = 0.3f;  // скорость мяча
    int score = 0;

    // основной цикл 
    while (window.isOpen()) { 
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed)
                window.close();
            if (event.type == Event::MouseButtonPressed) {
                if (event.mouseButton.button == Mouse::Left) { 
                    Vector2i pos = Mouse::getPosition(window);
                    if (b.menu) { 
                        if (o.exit.getGlobalBounds().contains(pos.x, pos.y))
                            window.close();
                        if (o.start.getGlobalBounds().contains(pos.x, pos.y)) { 
                            b.menu = false; 
                            b.game = true; 
                            resetGame(o, 3, 9, 30.0f);
                            score = 0; 
                        }
                    }
                    else if (b.game) { 
                        if (o.back.getGlobalBounds().contains(pos.x, pos.y)) { 
                            b.menu = true; 
                            b.game = false; 
                            b.gameOver = true;
                        }
                        if (o.reset.getGlobalBounds().contains(pos.x, pos.y)) { 
                            resetGame(o, 3, 9, 30.0f); 
                            b.gameOver = false;
                            score = 0; 
                        }
                    }
                }
            }
        }

        update(o, b, kx, ky, score);

        window.clear(Color(255, 127, 80)); 

 
        if (b.menu) {
            window.draw(o.exit);
            window.draw(o.start);
            window.draw(o.title); 
        }
        else if (b.game) {
            window.draw(o.back);
            window.draw(o.player);
            window.draw(o.ball);
            for (const auto& block : o.blocks) {
                window.draw(block);
            }
            window.draw(o.reset);
            o.scoreText.setString("Score: " + to_string(score));
            window.draw(o.scoreText); 
        }

        window.display();
    }


    return 0;
}
